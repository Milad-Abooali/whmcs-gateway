<?php
/**
 **************************************************************************
 * IranSamanBank Gateway
 * IranSamanBank.php
 * Send Request & Callback
 * @author           Milad Abooali <m.abooali@hotmail.com>
 * @version          1.0
 **************************************************************************
 * @noinspection PhpUnused
 * @noinspection PhpUndefinedFunctionInspection
 * @noinspection PhpUndefinedMethodInspection
 * @noinspection PhpDeprecationInspection
 * @noinspection SpellCheckingInspection
 * @noinspection PhpIncludeInspection
 * @noinspection PhpIncludeInspection
 */

global $CONFIG;

$cb_gw_name    = 'IranSamanBank';
$cb_output     = ['POST'=>$_POST,'GET'=>$_GET];
$action 	   = isset($_GET['a']) ? $_GET['a'] : false;

$root_path     = '../../../';
$includes_path = '../../../includes/';
include($root_path.((file_exists($root_path.'init.php'))?'init.php':'dbconnect.php'));
include($includes_path.'functions.php');
include($includes_path.'gatewayfunctions.php');
include($includes_path.'invoicefunctions.php');

$modules       = getGatewayVariables($cb_gw_name);
if(!$modules['type']) die('Module Not Activated');

$invoice_id    = $_REQUEST['invoiceid'];
$amount_rial   = intval($_REQUEST['amount']);
$amount        = $amount_rial / $modules['cb_gw_unit'];
$callback_URL  = $CONFIG['SystemURL']."/modules/gateways/$cb_gw_name/payment.php?a=callback&invoiceid=". $invoice_id.'&amount='.$amount_rial;
$invoice_URL   = $CONFIG['SystemURL']."/viewinvoice.php?id=".$invoice_id;

/**
 * Telegram Notify
 * @param $notify
 */
function notifyTelegram($notify) {
    global $modules;
    $row = "------------------";
    $pm= "\n".$row.$row.$row."\n".$notify['title']."\n".$row."\n".$notify['text'];
    $chat_id = $modules['cb_telegram_chatid'];
    $botToken = $modules['cb_telegram_bot'];
    $data = ['chat_id' => $chat_id, 'text' => $pm];
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, "https://api.telegram.org/bot$botToken/sendMessage");
    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
    curl_setopt($curl, CURLOPT_TIMEOUT, 10);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_exec($curl);
    curl_close($curl);
}

/**
 * Email Notify
 * @param $notify
 */
function notifyEmail($notify) {
    global $modules;
    global $cb_output;
    $receivers = explode(',', $modules['cb_email_address']);
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";
    $headers .= "From: ".$modules['cb_email_from']."\r\n";
    if($receivers) foreach ($receivers as $receiver)
        $cb_output['mail'][] = mail($receiver, $notify['title'], $notify['text'], $headers);
}

/**
 * Payment Failed
 * @param $log
 */
function payment_failed($log)
{
    global $modules;
    global $cb_gw_name;
    global $cb_output;
    $log['status'] = "unpaid";
    $cb_output['payment_failed']=$log;
    logTransaction($modules["name"], $log, "ناموفق");
    if($modules['cb_email_on_error'] || $modules['cb_telegram_on_error']){
        $notify['title'] = $cb_gw_name . ' | ' . "تراکنش ناموفق";
        $notify['text'] = '';
        foreach ($log as $key=>$item)
            $notify['text'] .= "\n\r$key: $item";
        if ($modules['cb_email_on_error']) notifyEmail($notify);
        if ($modules['cb_telegram_on_error']) notifyTelegram($notify);
    }
}

/**
 * Payment Success
 * @param $log
 */
function payment_success($log)
{
    global $modules;
    global $cb_gw_name;
    global $cb_output;
    $log['status'] = "OK";
    $cb_output['payment_success']=$log;
    logTransaction($modules["name"], $log, "موفق");
    if($modules['cb_email_on_success'] || $modules['cb_telegram_on_success']){
        $notify['title'] = $cb_gw_name . ' | ' . "تراکنش موفق";
        $notify['text'] = '';
        foreach ($log as $key=>$item)
            $notify['text'] .= "\n\r$key: $item";
        if ($modules['cb_email_on_success']) notifyEmail($notify);
        if ($modules['cb_telegram_on_success']) notifyTelegram($notify);
    }
}

/**
 * Redirecttion
 * @param $url
 */
function redirect($url)
{
    if (headers_sent())
        echo "<script>window.location.assign('$url')</script>";
    else
        header("Location: $url");
    exit;
}

/**
 * Show Error
 * @param $text
 */
function show_error($text)
{
    global $cb_gw_name;
    global $invoice_URL;
    echo "<img src='/modules/gateways/$cb_gw_name/logo.png' alt='$cb_gw_name'>
        <p>$text</p><a href='$invoice_URL'>بازگشت</a>";
}

/**
 * Get DB Amount
 * @return float
 */
function get_db_amount(){
    global $modules;
    global $invoice_id;
    $sql = select_query("tblinvoices", "", array("id" => $invoice_id));
    $sql_res = mysql_fetch_array($sql);
    $db_amount = strtok($sql_res['total'], '.');
    return $db_amount * $modules['cb_gw_unit'];
}

/**
 * Error Codes Translator
 * @param string $ResCode
 * @return string
 */
function translate_error($ResCode='')
{
    switch($ResCode)
    {
        case '-1':$prompt="خطا درپردازش اطلاعات ارسالی";break;
        case '-3':$prompt="ورودی حاوی کارکتر غیرمجاز";break;
        case '-4':$prompt="کلمه عبور یا کد فروشنده اشتباه است.";break;
        case '-6':$prompt="سند قبلا برگشت کامل یافته است.";break;
        case '-7':$prompt="رسید دیجیتال خالی است.";break;
        case '-8':$prompt="طول ورودی بیشتر از حد مجاز است";break;
        case '-9':$prompt="وجود کاراکترهای غیرمجاز در مبلغ بازگشتی";break;
        case '-10':$prompt="رسید دیجیتال بصورت Base64 نیست.";break;
        case '-11':$prompt="طول ورودی ها کمتر از حد مجاز است.";break;
        case '-12':$prompt="مبلغ برگشتی منفی است.";break;
        case '-13':$prompt="مبلغ برگشتی برای برگشت جزئی بیش از مبلغ برگشت خورده ی رسید دیجیتال است.";break;
        case '-14':$prompt="چنین تراکنشی تعریف نشده است.";break;
        case '-15':$prompt="مبلغ برگشتی بصورت اعشاری داده شده است.";break;
        case '-16':$prompt="خطای داخلی سیستم";break;
        case '-17':$prompt="برگشت زدن جزوی تراکنش مجاز نمیباشد.";break;
        case '-18':$prompt="ای پی سرور فروشنده نامعتبر است.";break;
        default:$prompt="خطاي نامشخص.";
    }
    return $prompt;
}

if($action==='callback') {
    if(empty($invoice_id)) die('Invoice ID Missing!');
    $cb_output['invoice_id'] = $invoice_id;
    // Response Items From Bank
    $transaction_id    = $_POST['RefNum'];
    $order_id          = $_POST['ResNum'];
    if(!empty($order_id) && !empty($transaction_id)) {
        $cb_output['transaction_id'] = $transaction_id;
        $cb_output['order_id'] = $order_id;
        // Check Invoice ID by WHMCS
        $invoice_id = checkCbInvoiceID($invoice_id, $modules['name']);
        // Check Transaction ID by WHMCS
        checkCbTransID($transaction_id);
        // Check Invoice Amount From Database
        $db_amount_rial = get_db_amount();
        $cb_output['db_amount_rial'] = $db_amount_rial;

        // Verify Transaction by Gateway
        $soapclient = new soapclient('https://verify.sep.ir/Payments/ReferencePayment.asmx?WSDL');
        $VerifyTransaction_res = $soapclient->VerifyTransaction($transaction_id, $modules['cb_gw_id']);
        $cb_output['VerifyTransaction_res'] = $VerifyTransaction_res;
        if($VerifyTransaction_res > 0) {
            $log = array(
                'Invoice'        => $invoice_id,
                'Amount'         => number_format($amount).(($modules['cb_gw_unit']>1)?' Toman':' Rial'),
                'Order'          => $order_id,
                'Transaction'    => $transaction_id
            );
            if($VerifyTransaction_res == $db_amount_rial) {
                addInvoicePayment($invoice_id, $transaction_id, $amount, 0, $cb_gw_name);
                $log['CardNumber']  = $_POST['SecurePan'];
                $log['TRACENO']     = $_POST['TRACENO'];
                payment_success($log);
            }
            else {
                $log['Error']  = "یکسان نبودن مبلغ پرداختی با فاکتور";
                payment_failed($log);
            }
        }
        else {
            $log['Error']  = translate_error($VerifyTransaction_res);
            payment_failed($log);
        }
    }
    //print("<pre>".print_r($cb_output,true)."</pre>");
    redirect($invoice_URL);
}
elseif ($action==='send'){
    if($modules['cb_gw_method']==='Token') {
        try {
            $SoapClient = new SoapClient('https://sep.shaparak.ir/payments/initpayment.asmx?wsdl', array('encoding' => 'UTF-8'));
            $token = $SoapClient->RequestToken($modules['cb_gw_id'], $invoice_id, $amount_rial);
            if(!empty($token) and strlen($token)>10) {
                echo "<form id='$cb_gw_name' action='https://sep.shaparak.ir/payment.aspx' method='post'>
                <input type='hidden' name='RedirectURL' value='$callback_URL'>
                <input type='hidden' name='Token' value='$token'></form>
                <script>document.forms['$cb_gw_name'].submit()</script>
                <img src='/modules/gateways/$cb_gw_name/logo.png' alt='$cb_gw_name'>";
            }
            else {
                show_error($token.'<br>'.translate_error($token));
            }
        } catch (SoapFault $e) {
            show_error($e);
        }
    }
    else if($modules['cb_gw_method']==='Old') {
        echo "<form id='$cb_gw_name' action='https://sep.shaparak.ir/payment.aspx' method='post'>
            <input type='hidden' name='Amount' value='$amount_rial'>
            <input type='hidden' name='ResNum' value='$invoice_id'>
            <input type='hidden' name='RedirectURL' value='$callback_URL'>
            <input type='hidden' name='MID' value='".$modules['cb_gw_id']."'>
            </form><br><img src='/modules/gateways/$cb_gw_name/logo.png' alt='$cb_gw_name'>
            <script>document.forms['$cb_gw_name'].submit();</script>";
    }
    else{
        show_error("هیچ متد پرداختی انتخاب نشده است!");
    }
}